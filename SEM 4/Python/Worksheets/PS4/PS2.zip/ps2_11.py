if __name__ == '__main__':
    lt=[12,24,36,48,60,72,84,96]
    x=[]
    x.append(lt[3])
    x.append(lt[4])
    print(x)#mid elements in another list
    lt=lt[:3]+lt[5:]#slicing mid elements from original list
    print(lt)
    lt[3:3]=x#inserting using slicing
    print(lt)