if __name__ == '__main__':
    parrot = ['the','dead','parrot','sketch']
    for item in parrot:
        print(f'{item.capitalize()} {len(item)}')