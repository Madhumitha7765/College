inputA = input("Enter the string : ").split(" ", 1)
if inputA[0] == "print":
    print(inputA[1])