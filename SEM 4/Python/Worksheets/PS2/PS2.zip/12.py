Inputlist = [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
Evenlist = []
for value in Inputlist:
    if value%2 == 0:
        Evenlist.append(value)

print(Evenlist)
