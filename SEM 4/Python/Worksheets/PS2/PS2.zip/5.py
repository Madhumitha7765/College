numbers = [2, 7, 456, 12, 90, -13, 45, 45, -1, 134]
sets = set(numbers)

print("Length of the set is:", end=" ")
print(len(sets))

# duplicate values not taken in len function