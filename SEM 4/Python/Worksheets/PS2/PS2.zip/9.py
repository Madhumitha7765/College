colors = {}
colors = {'white','red','blue','green'}

colors.remove('red')
if 'yellow' in colors:
    print('Yes')
else:
    print('No')