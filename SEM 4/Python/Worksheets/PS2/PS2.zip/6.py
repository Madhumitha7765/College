numbers = [2, 7, 456, 12, 90, -13, 45, 45, -1, 134]
sets = set(numbers)

# print("Before : ")
# print(sets)

sets.clear()

# print("after :")
# print(sets)