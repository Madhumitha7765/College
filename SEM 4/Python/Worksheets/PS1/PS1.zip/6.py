# Dictionaries are used to store data values
# in key:value pairs.

n = int(input('Enter the integral number : '))

d = {}

for i in range(1, n+1):
    d[i] = i * i

print(d)

