string = input("Enter the value of a: ")
a = string
sum = 0

for i in range(0, 4):
    str2 = int(string)
    sum += str2
    string += a

print(sum)